# Price-Prediction-of-Agricultural-Commodities
Developed a web-based application to predict the future prices of selected agricultural commodities using Machine Learning. The project leverages Flask for backend operations and HTML, CSS, and JavaScript for frontend development. The model analyzes historical price trends and provides insights for farmers and traders. 
